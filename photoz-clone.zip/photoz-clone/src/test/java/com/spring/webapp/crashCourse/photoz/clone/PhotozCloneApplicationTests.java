package com.spring.webapp.crashCourse.photoz.clone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotozCloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
